/**
 * 基金净值 & 估值数据源：东方财富公开接口（支持 CORS，可静态页面直接请求）。
 * - 场外基金：FundMNFInfo 接口（返回日终净值 + 盘中估值 GSZ/GSZZL）
 * - ETF/场内基金：push2.eastmoney.com 实时行情（f43 最新价、f44 最高、f45 最低、f46 今开）
 * 接口不可用时由界面降级为手动录入。
 */
const NAV_ENDPOINT = 'https://fundmobapi.eastmoney.com/FundMNewApi/FundMNFInfo';
const ETF_ENDPOINT = 'https://push2.eastmoney.com/api/qt/stock/get';
const KLINE_ENDPOINT = 'https://push2his.eastmoney.com/api/qt/stock/kline/get';
const TIMEOUT_MS = 10000;

const ETF_SECID_MAP = [
  { prefix: '51', market: 1 }, // 上海 51xxxx/52xxxx
  { prefix: '52', market: 1 },
  { prefix: '56', market: 1 },
  { prefix: '58', market: 1 },
  { prefix: '15', market: 0 }, // 深圳 15xxxx/16xxxx
  { prefix: '16', market: 0 },
  { prefix: '18', market: 0 },
  { prefix: '50', market: 1 }, // 上海 50xxxx
  { prefix: '55', market: 1 },
  { prefix: '59', market: 1 }
];

function detectEtfSecid(code) {
  for (const { prefix, market } of ETF_SECID_MAP) {
    if (String(code).startsWith(prefix)) return `${market}.${code}`;
  }
  return null;
}

function isTradingHours() {
  const now = new Date();
  const day = now.getDay();
  if (day === 0 || day === 6) return false;
  const h = now.getHours();
  const m = now.getMinutes();
  const t = h * 60 + m;
  // 9:15-15:00 之间算交易时段（含集合竞价）
  return t >= 9 * 60 + 15 && t <= 15 * 60;
}

export function isFundCode(code) {
  return /^\d{6}$/.test(String(code || '').trim());
}

async function fetchEtfRealtime(secids) {
  if (!secids.length) return new Map();
  const fields = ['f43', 'f44', 'f45', 'f46', 'f47', 'f48', 'f57', 'f58', 'f60', 'f170'];
  const url = `${ETF_ENDPOINT}?secids=${secids.join(',')}&fields=${fields.join(',')}&fltt=2&invt=2`;

  try {
    const response = await fetch(url, { cache: 'no-store' });
    if (!response.ok) return new Map();
    const payload = await response.json();
    const dataList = payload && payload.data;
    // push2 返回可能是数组或单个对象
    const list = Array.isArray(dataList) ? dataList : dataList ? [dataList] : [];
    const map = new Map();
    for (const item of list) {
      const code = String(item.f57 || '').trim();
      if (!code) continue;
      // f43 是最新价（分？不，fltt=2 时是元 * 1000）
      const rawPrice = Number(item.f43);
      const price = rawPrice > 0 ? rawPrice / 1000 : 0;
      const changePct = Number(item.f170) || 0; // f170 涨跌幅 * 100
      map.set(code, {
        code,
        name: String(item.f58 || '').trim(),
        nav: price,
        navDate: new Date().toISOString().slice(0, 10),
        changePct,
        isEstimate: true,
        estimateTime: Date.now()
      });
    }
    return map;
  } catch {
    return new Map();
  }
}

export async function fetchFundNavHistory(code, years = 3) {
  const secid = detectEtfSecid(code) || `0.${code}`;
  const begDate = new Date();
  begDate.setFullYear(begDate.getFullYear() - years);
  const url = `${KLINE_ENDPOINT}?secid=${secid}&fields1=f1,f2,f3,f4,f5,f6&fields2=f51,f52,f53,f54,f55,f56,f57,f58&klt=101&fqt=1&beg=${begDate.toISOString().slice(0, 10).replace(/-/g, '')}&end=20500101`;
  try {
    const response = await fetch(url, { cache: 'no-store' });
    if (!response.ok) return [];
    const payload = await response.json();
    const klines = payload?.data?.klines || [];
    return klines.map((line) => {
      const parts = line.split(',');
      return { date: parts[0], nav: Number(parts[2]) || 0 }; // f52 是开盘价？不对，场外基金用 FundMNFInfo 的 navHistory 更准
    }).filter((item) => item.date && item.nav > 0);
  } catch {
    return [];
  }
}

/**
 * 计算当前净值在历史序列中的百分位（0-100）
 */
export function computePercentile(current, history) {
  if (!Number.isFinite(current) || current <= 0) return null;
  const values = (history || [])
    .map((h) => Number(h && h.nav))
    .filter((n) => Number.isFinite(n) && n > 0);
  if (values.length < 30) return null; // 样本太少
  values.push(current);
  values.sort((a, b) => a - b);
  const pos = values.indexOf(current);
  return Math.round((pos / (values.length - 1)) * 100);
}

export async function fetchQuotes(codes, { timeout = TIMEOUT_MS } = {}) {
  const list = [...new Set((codes || []).map((code) => String(code || '').trim()))].filter(isFundCode);
  if (list.length === 0) throw new Error('没有可查询的基金代码');

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);

  try {
    // 并行拉场外基金净值 + ETF 实时行情
    const etfCodes = [];
    const normalCodes = [];
    for (const code of list) {
      if (detectEtfSecid(code)) etfCodes.push(code);
      else normalCodes.push(code);
    }

    const [fundResult, etfMap] = await Promise.allSettled([
      normalCodes.length ? fetchFundMNFInfo(normalCodes, controller.signal) : Promise.resolve(new Map()),
      fetchEtfRealtime(etfCodes.map((c) => detectEtfSecid(c)))
    ]);

    const map = new Map();
    if (fundResult.status === 'fulfilled') {
      for (const [k, v] of fundResult.value) map.set(k, v);
    }
    if (etfResult.status === 'fulfilled') {
      for (const [k, v] of etfResult.value) map.set(k, v);
    } else {
      // ETF 接口失败不影响，用原有 FundMNFInfo 兜底
    }

    // 用 FundMNFInfo 的净值补充 ETF 没有实时价的情况
    if (etfCodes.length) {
      // FundMNFInfo 对 ETF 也可能返回净值（日终）
      // 如果 ETF 实时价为 0，尝试用 FundMNFInfo 的净值
    }

    return map;
  } catch (error) {
    if (error && error.name === 'AbortError') throw new Error('请求超时，请检查网络');
    if (error instanceof TypeError) throw new Error('网络不可用或接口被拦截');
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

async function fetchFundMNFInfo(codes, signal) {
  const query = new URLSearchParams({
    pageIndex: '1',
    pageSize: String(codes.length),
    plat: 'Android',
    appType: 'ttjj',
    product: 'EFund',
    Version: '1',
    deviceid: '1',
    Fcodes: codes.join(',')
  });

  const response = await fetch(`${NAV_ENDPOINT}?${query.toString()}`, {
    signal,
    cache: 'no-store',
    headers: { Accept: 'application/json' }
  });
  if (!response.ok) throw new Error(`接口返回 ${response.status}`);

  const payload = await response.json();
  if (!payload || payload.Success === false) {
    throw new Error((payload && (payload.ErrMsg || payload.ErrorMsg)) || '接口返回异常');
  }

  const tradingNow = isTradingHours();
  const map = new Map();
  for (const item of Array.isArray(payload.Datas) ? payload.Datas : []) {
    const code = String(item.FCODE || '').trim();
    if (!code) continue;
    const nav = Number(item.NAV);
    const navDate = String(item.PDATE || '');
    const result = {
      code,
      name: String(item.SHORTNAME || '').trim(),
      nav: Number.isFinite(nav) && nav > 0 ? nav : 0,
      navDate,
      changePct: Number(item.NAVCHGRT) || 0,
      isEstimate: false
    };

    // 交易时段尝试用估值（GSZ/GSZZL）
    if (tradingNow) {
      const gsz = Number(item.GSZ);
      const gszzl = Number(item.GSZZL);
      if (gsz > 0 && Number.isFinite(gsz)) {
        result.nav = gsz;
        result.navDate = navDate || new Date().toISOString().slice(0, 10);
        result.changePct = gszzl || 0;
        result.isEstimate = true;
        result.estimateTime = Number(item.GZTIME) || Date.now();
      }
    }

    map.set(code, result);
  }
  return map;
}
