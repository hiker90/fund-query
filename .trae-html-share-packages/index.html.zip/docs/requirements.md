# FundPilot 需求文档

> 本文档是 FundPilot 项目的唯一权威需求文档。任何需求变更必须先同步更新本文档，再改代码。
> 路径：`docs/requirements.md`

---

## 一、产品概述

### 1.1 一句话定义

基于「一次性建仓 + 闲置资金分档补仓」策略的移动端基金监控工具，纯静态页面，零后端，零 npm 依赖，可直接托管 GitHub Pages。

### 1.2 目标平台

- 移动端优先：iPhone Safari（iOS 安全区适配、16px 输入防缩放）
- 桌面浏览器可用

### 1.3 核心约束

- 禁止引入任何 npm 依赖
- 禁止引入任何后端服务
- 所有数据仅保存在本机 localStorage，不上传任何服务器

### 1.4 核心价值

- 成本可视化：每次买入、补仓、卖出后，摊薄成本如何变化一目了然
- 规则自动化：止损/止盈/分档补仓/移动止盈全部自动计算，不需要手动算
- 宏观参考：股债性价比分位、美债、美元、商品一览，辅助决策
- 配置再平衡：按类别设置目标比例，实时看偏差和调仓金额

---

## 二、功能模块

### 2.1 底部导航 Tab

5 个固定 tab，从左到右：

| Tab | Hash | 页面 | 默认 |
|-----|------|------|------|
| 宏观 | `#/macro` | 宏观观察（默认首页） | ✅ |
| 持仓 | `#/holdings` | 持仓监控与基金列表 | |
| 策略 | `#/strategy` | 全局策略模板配置 | |
| 配置 | `#/allocation` | 资产配置分析（类别+目标比例+偏差） | |
| 数据 | `#/data` | 数据备份、导入、批量导入底仓 | |

### 2.2 宏观观察页

#### 2.2.0 资产方向速览（页面顶部首要位置）

权益 / 债券 / 黄金 / 石油四个资产各一行，每行 = 资产名（倾向色）+ 一句话方向建议，基于下方宏观指标自动推导（规则同 2.2.1 verdict，指标暂缺时显示「数据暂缺，建议观望」类文案）：

| 资产 | 主信号 | 方向规则 |
|------|--------|---------|
| 权益 | 股债性价比分位 + 美债曲线 | 分位 ≥70 且未倒挂 → 增配；分位 ≤30 或曲线倒挂 → 控仓；其余中性 |
| 债券 | 中国 10Y−2Y 期限利差 | ≤30bp 宽松友好 → 增配；≥60bp 修复预期 → 控久期；其余中性 |
| 黄金 | 美国实际利率（近似） | ≤0% → 增配；≥2% → 减配；其余中性 |
| 石油 | WTI 同比 | ≥30% 高位 → 不宜追高；≤−20% 低位 → 少量关注；其余观望 |

#### 2.2.1 指标卡片（每个核心指标一张卡，各带独立渐变背景）

每张卡片 = 指标数值 + **一句话资产平衡方向**（verdict，带倾向色标注）：

| 卡片 | 渐变 | 指标 | 平衡问题 |
|------|------|------|---------|
| 股债性价比 | grad-violet | 盈利收益率（1/PE）、PE-TTM、股债收益比、ERP、**5年历史分位**（进度条） | 权益 vs 债券 |
| 美国实际利率（近似） | grad-blue | 美国10Y、WTI 同比（通胀近似）、实际利率 = US10Y − WTI同比 | 黄金 vs 债券 |
| 美债期限利差 | grad-blue | 美国10Y、美国2Y、10Y−2Y 利差（bp） | 权益风险总敞口 |
| 中国国债期限利差 | grad-teal | 中国10Y、中国2Y、10Y−2Y 利差（bp） | 债券配置友好度 |
| 通胀与景气 | grad-teal | CPI 同比、PPI 同比、PPI−CPI 剪刀差、制造业/非制造业 PMI | 经济周期与股债环境 |
| COMEX 黄金 | grad-gold | 金价现价 + 日涨跌、美元指数、实际利率（近似） | 黄金价格与方向（美元指数并入本卡） |
| NYMEX 原油 | grad-gold | 油价现价 + 日涨跌、WTI 同比（365 天） | 石油价格与通胀周期 |

股债性价比卡中 PE-TTM 标注为「计算因子」，并明确展示换算关系「盈利收益率 = 1 ÷ PE-TTM」。

verdict 倾向色：ok（增配方向）/ warn（控制风险）/ danger（倒挂预警）/ accent（中性维持）。

verdict 规则（唯一权威：`views.js`）：

| 指标 | 条件 | 结论示例 |
|------|------|---------|
| 股债收益比分位 | ≥70 | 权益性价比突出，宜增配权益、减配债券 |
| | ≤30 | 债券更占优，宜增配债券、控制权益仓位 |
| 美国实际利率 | ≥2% | 黄金机会成本高，宜减黄金、增债券 |
| | ≤0% | 实际利率为负，利于黄金，宜增黄金 |
| 美债期限利差 | <0（倒挂） | 衰退预警，降权益、增债券/黄金 |
| | <20bp | 曲线明显走平，逐步控制权益仓位 |
| 中国期限利差 | ≥60bp | 经济修复预期强，控债券久期、增权益 |
| | ≤30bp | 宽松预期主导，债券偏友好 |
| 制造业 PMI | ≥51 | 景气扩张，经济动能强，权益环境友好 |
| | 50–51 | 扩张区间，经济平稳，维持现有配置 |
| | 49–50 | 回落至荣枯线下，动能减弱，暂不加仓 |
| | <49 | 景气收缩，债券偏友好，增债控权益 |

#### 2.2.2 数据源

| 数据 | 接口 |
|------|------|
| 美债10Y/2Y、中债10Y/2Y、美元、黄金、原油、沪深300 | 东财 `push2.eastmoney.com/api/qt/ulist.np/get` 批量接口（8 标的一次请求） |
| 沪深300 PE-TTM | 东财 `push2.eastmoney.com/api/qt/stock/get`（f115 字段） |
| CPI / PPI / PMI 月度数据 | 东财数据中心 `datacenter-web.eastmoney.com/api/data/v1/get`（reportName：RPT_ECONOMY_CPI / RPT_ECONOMY_PPI / RPT_ECONOMY_PMI，CORS 开放） |
| 沪深300 + 中债10Y 5年日K + WTI 1年日K | 东财 `push2his.eastmoney.com/api/qt/stock/kline/get` |

#### 2.2.3 缓存策略

- 内存 5 分钟缓存（`macro.js::cache`），过期自动刷新
- 经济数据（CPI/PPI/PMI）单独「当日有效」内存缓存（`macro.js::economyCache`），月度数据无需高频刷新；失败不写缓存、下次可重试
- 历史序列（K线）拉失败不阻断现价展示，equityBond 字段为 null
- 请求超时 10 秒，自动 abort

#### 2.2.4 股债性价比分位计算

```
盈利收益率 = EPS_now / 当前价格（常数盈利近似）
股债收益比 = 盈利收益率 / (中国10Y收益率 / 100)
ERP = 盈利收益率 − 中国10Y收益率
历史分位 = 严格小于当前值的样本数 / (N−1) × 100
```

- 分位窗口：近 5 年日频数据
- 样本数不足 50 时返回 null

#### 2.2.5 已知边界

- **盈利收益率近似**：采用常数盈利（EPS_now）而非动态盈利，界面已标注
- **实际利率近似**：美国 CPI/通胀预期无东财 CORS 接口，以「US10Y − WTI 同比」近似实际利率，界面已标注
- **期限利差口径**：中/美均采用 10Y−2Y 计算（东财全球债有 2Y 品种：171.CN2Y / 171.US2Y），短端对货币政策/资金面更敏感，界面已标注
- **代理行情**：兜底层天天基金代理仅提供黄金/原油/沪深300 的日涨跌（估算值），无价格与收益率；降级提示在页面底部展示
- **经济数据为月度口径**：CPI/PPI/PMI 每月 9 日前后更新，卡片展示最新月份值与 PMI 荣枯线方向，不做历史分位

#### 2.2.6 宏观指标计算口径（`macro.js`）

```
期限利差(bp) = (长端收益率% − 短端收益率%) × 100
WTI 同比% = (WTI 现价 / 365 天前 WTI 收盘价 − 1) × 100
美国实际利率%（近似）= 美国10Y收益率% − WTI同比%
```

### 2.3 持仓监控页

#### 2.3.1 Hero 卡

| 字段 | 计算 |
|------|------|
| 持仓总市值 | Σ 基金市值（有持仓的基金） |
| 持仓盈亏 | 总市值 − 总成本 |
| 持仓成本 | Σ 基金成本 |
| 持仓盈亏率 | 盈亏 / 成本 × 100% |
| 基金数量 | state.funds.length |
| 净值更新时间 | 所有基金中最新 navUpdatedAt |

#### 2.3.2 状态筛选 Tab（胶囊形状，横向滚动）

5 个筛选 tab，首位「全部」默认选中，每个 tab 带数量角标：

| Tab | 匹配状态 |
|-----|---------|
| 全部 | 所有基金 |
| 可补仓 | `add`（已触及未执行的补仓档位） |
| 止盈 | `takeProfit` + `trailing`（触发止盈、移动止盈） |
| 止损 | `stop` + `nearStop`（触发止损、接近止损） |
| 运行中 | `normal` |

- 选中态：主色填充 + 白色文字 + 白色半透明角标
- Hero 卡统计始终基于全部基金，筛选只影响下方列表

#### 2.3.3 基金卡片

每张卡片：

```
[标题] 基金名称 · 6位代码 [估值标签]    [状态胶囊 badge]
[净值] 当前净值     净值日期 YYYY-MM-DD
[指标] 摊薄成本 | 持仓收益率 | 市值
[rule-track] 绿→橙→红渐变轨道 + 止损标记 + 成本标记 + 止盈标记 + 黑色圆点当前位置
[hint] 下一档补仓提示 / 已触及提示 / 最终储备提示
```

状态胶囊 tone：

| status | label | tone | rank |
|--------|-------|------|------|
| stop | 触发止损 | danger | 0 |
| trailing | 移动止盈 | warn | 1 |
| takeProfit | 触发止盈 | accent | 2 |
| add | 可补仓 | accent | 3 |
| nearStop | 接近止损 | warn | 4 |
| normal | 运行中 | ok | 5 |

卡片按 rank 升序排列（最紧急的排最前）。

标题行内还展示 FTYPE 原值小字（如「指数型-股票」，来自东财 F10，随自动归类写入 fund.ftype）和「估值水平」小胶囊（如「估值 78%·高估」），按基金类型取不同估值序列的分位：

| 序列分位 percentile | label | tone |
|--------------------|-------|------|
| ≤30 | 低估 | down（绿） |
| 30–70 | 正常 | flat（中性灰） |
| ≥70 | 高估 | warn（橙） |

按基金类型分流（F10 基本信息优先，assetClass 兜底）：

| 基金类型 | 判定条件 | 估值序列 |
|---------|---------|---------|
| 债券基金 | assetClass=BOND 或 FTYPE 含「债券」 | 中债10Y收益率日K 分位**取反**（收益率低=债贵=高估） |
| 黄金基金 | assetClass=GOLD 或 FTYPE「指数型-其他」且 INDEXCODE=AU9999 | COMEX 黄金（101.GC00Y）日K 收盘分位 |
| 指数股票基金 | FTYPE 以「指数型-股票」开头 + 6 位 INDEXCODE + INDEXTEXCH ∈ {0,1} | 跟踪指数日K 收盘分位（价格分位 ≡ 常数盈利 PE 分位） |
| 主动/行业/QDII 基金 | 其余全部 | **不展示估值标签** |

- percentile = 序列中 ≤ 当前值（最新收盘）的样本数 / 样本总数 × 100；窗口约 2 年自然日（≈500 个交易日）
- 数据源：东财 F10 `FundMNBasicInformation`（FTYPE / INDEXCODE / INDEXTEXCH）+ push2his K 线接口
- 接口失败或样本 < 20 条时不显示；历史仅存内存缓存（30 分钟，基金代码 + 序列 key 双层去重），禁止写入 localStorage
- 「无策略」（NONE）基金的状态胶囊为中性灰 badge-flat，不参与预警排序（排在运行中之后）

#### 2.3.4 净值刷新

- 进入持仓页时自动拉取一次净值（从未拉取过，或距上次自动拉取超过 5 分钟才触发，模块级变量记录）
- 点击右上角 icon-btn 批量刷新全部基金（手动触发，不受自动间隔限制）
- 刷新中按钮旋转 + disabled
- 单只基金可在详情页单独刷新

#### 2.3.5 添加基金

右下角 FAB `＋` → 底部弹层：

1. 输入 6 位代码
2. 点「查询名称与净值」（调东财接口自动补全）
3. **资产类别**下拉（有预设类别时为 select，选项从 state.categories 动态生成；无预设时为自由 input）
4. 初始底仓区域，双模式切换（默认选中「市值+收益率」）：
   - **市值 + 收益率**：输入当前持仓金额 + 收益率%，自动反推成本/份额/成本净值
     - 反推公式：成本 = 市值 / (1 + r/100)，份额 = 市值 / 当前净值
   - **成交金额 + 净值**：输入买入金额 + 成交净值
5. 实时预览反推结果（成本/份额/成本净值）
6. 提交时自动生成一条 source='BASE' 的 BUY 交易记录

#### 2.3.6 基金详情页

点击卡片进入 `#/fund/{id}`：

- 基金名称、代码、净值、净值日期
- 三指标：摊薄成本 / 持仓收益率 / 市值
- **策略阶梯**：止损线、持仓成本、止盈线三行，显示距当前价格还有多少%
- **补仓模拟器**：输入拟补金额 + 成交净值，实时预览：新成本、新止损线、新止盈线、成本降幅、新市值
- **交易流水**：按日期排序的所有买卖记录，显示类型/日期/净值/金额/手续费/来源/备注
- **手动录入净值**入口
- 「删除此基金」入口

---

### 2.4 策略配置页

#### 2.4.1 双预置方案（普通 / 激进）

策略不再支持自由编辑参数，改为两套只读预置（`strategy.js::STRATEGY_PRESETS`）。策略页展示两张只读预置卡 + 全局默认单选，保存走 `data-form="strategy"` 表单提交：

| 参数 | 普通 NORMAL | 激进 AGGRESSIVE |
|------|------------|----------------|
| stopLossPct 止损比例 | 12% | 8% |
| takeProfitPct 止盈比例 | 20% | 25% |
| takeProfitSellRatio 第一层止盈卖出 | 40% | 50% |
| trailingStopPct 移动止盈回撤 | 8% | 10% |
| addTiers 分档补仓 | 5%/1200、10%/2000、15%/2800 | 4%/1500、8%/2500、12%/3500 |
| reserveAmount 最终储备 | 2400 元 | 3000 元 |
| reserveTriggerPct 储备触发跌幅 | 20% | 15% |
| addPositionSellPct 独立了结收益 | 6% | 8% |

- `settings.defaultStrategy` ∈ `'NORMAL' | 'AGGRESSIVE'`；`DEFAULT_STRATEGY` 导出保留（= `STRATEGY_PRESETS.NORMAL`，兼容旧引用）
- 新基金 `strategyOverride` 默认 null（跟随全局）

#### 2.4.2 单基金覆盖

基金详情「策略覆盖」弹层改为下拉四选一（fund.strategyOverride）：

| 值 | 含义 |
|----|------|
| null | 跟随全局默认 |
| `'NORMAL'` | 使用普通方案 |
| `'AGGRESSIVE'` | 使用激进方案 |
| `'NONE'` | 不启用策略：不计算止损/止盈/分档线，卡片显示「无策略」badge（中性色），不参与预警排序 |

策略解析唯一入口：`strategy.js::resolveStrategyByKey(defaultKey, fundStrategyKey)` —— fundStrategyKey='NONE' 返回 null，非法/空跟随全局，其余返回对应预置策略对象。

---

### 2.5 资产配置页

#### 2.5.1 页面结构

```
Hero 卡：总资产市值 + 目标配置合计（接近100%绿/远离红）
持仓占比总览：SVG donut 饼图 + 图例（含偏差进度条）
类别占比与偏差：N 行可展开/收起的类别行
三资产再平衡：权益/债券/黄金大类目标比例（可编辑）+ 实际占比 + 偏差 + 调仓金额
未分类资产：下拉菜单分配到已有类别
类别管理：编辑名称/目标比例/删除/新增
```

#### 2.5.2 饼图与图例偏差条

- 纯 SVG donut 环形图，零依赖
- 每个类别一个扇区，8 色循环调色板
- 图例每个类别下方有偏差进度条（参考持仓页 rule-track 风格）：
  - **中线 = 目标基准**（灰色竖线标记）
  - **低配向左绿色延伸**，**超配向右红色延伸**
  - 偏差 < 0.05% 或未设目标的类别不显示偏差条
  - 悬停提示：目标% · 实际% · 偏差方向

#### 2.5.3 类别占比与偏差行

默认收起，点击头部展开查看该类别下的基金明细：

```
[类别头部] 名称 · N只     [市值] [偏差%] [›箭头]
[再平衡标签] 需买入 ¥xxx / 需卖出 ¥xxx / 已达标
[占比条] 绿→橙→红渐变轨道 + 灰色竖线=目标 + 黑色圆点=实际
[展开后] 每只基金：名称 · 市值 · 移除按钮
```

- 超配：偏差红，需卖出标签红
- 低配：偏差绿，需买入标签蓝
- 未设目标的类别：半透明 + 「未设目标」标签
- 行按 |偏差| 降序排列，偏离最大的排最前

#### 2.5.4 再平衡金额

```
调整金额 = 目标市值 − 实际市值
目标市值 = 目标占比% × 总资产市值
正 = 需买入，负 = 需卖出
```

#### 2.5.5 三资产再平衡（权益 / 债券 / 黄金）

- 基金归属三个资产大类之一：`fund.assetClass` ∈ `EQUITY / BOND / GOLD`，缺省 `EQUITY`
- **自动归类**：添加/批量导入/持仓页估值加载时拉取东财 F10，按 `strategy.js::classifyAssetClass(ftype, indexCode)` 自动归入三资产——FTYPE 含「债券」→ BOND；含「黄金」或「指数型-其他」且跟踪 AU9999 → GOLD；其余 → EQUITY。`fund.assetClassAuto = false`（添加时显式选了债券/黄金，或配置页手动改过大类）后不再自动覆盖
- `fund.ftype` 持久化 FTYPE 原值（如「指数型-股票」），持仓页基金卡片标题行展示
- 大类目标比例在 `settings.assetTargets` 中配置（页面内联编辑，0–100）
- 添加基金弹层支持选择资产大类；配置页每只基金行内有下拉可改大类
- 每个大类一行：名称 + 目标%输入框 + 实际占比 + 偏差（正=超配红，负=低配绿）+ 调仓金额（需买入/需卖出/已达标）
- 偏差口径与类别偏差一致（见 4.6），但分母与分子均按大类聚合
- 大类下方展开该类基金清单（名称 + 市值 + 大类切换下拉）

#### 2.5.6 类别管理

- 每行：类别名 input + 目标比例% input + 删除 icon-btn
- 新增行：虚线分隔 + 类别名 + 目标% + 加号按钮（无「添加」文案）
- 删除类别时同步清空该类别下所有基金的 category 字段
- 重命名类别时自动把所有关联基金的旧名更新为新名

---

### 2.6 数据管理页

#### 2.6.1 整体备份导出

- 导出 JSON 格式，包含全部 state
- 文件头部标记 `{ app: 'FundPilot', version, exportedAt, data }`

#### 2.6.2 整体备份导入

- 选择文件或粘贴 JSON 文本
- 自动调用 `normalizeState` 做 schema 兼容
- 缺少 `funds` 字段时报错「文件格式不正确」

#### 2.6.3 批量导入底仓

**数据格式（极致精简 3 列）**：

```
代码,持仓金额,持仓收益率
110022,10500,5.2
161725,8200,-3.1
005827,12000
```

- 分隔符支持半角逗号、中文逗号、Tab（可直接从 Excel 复制粘贴）
- 首行含非数字字符自动跳过（表头）
- `#` 或 `//` 开头行视为注释
- 收益率可省略（默认 0），支持负数
- 同代码去重（保留最后一行）
- 支持「加载本地文件」：选择 `.csv` / `.txt` 文件（≤1MB），自动去除 UTF-8 BOM 填入文本框并触发解析预览；同一文件可重复选择

**导入流程**：

1. 粘贴文本或加载本地文件（自动解析）→ 查看解析预览
2. 预览表：逐行显示 ✓可导入 / ⚠重复 / ✗错误原因
3. 点「确认导入」：
   - 批量查询全部基金净值
   - 用「市值+收益率反推」公式生成底仓 BUY 交易记录
   - 已有基金一律跳过（不覆盖）
   - 净值查询失败的基金仍添加监控，但无底仓
4. 结果 toast：「导入完成：N 只已登记底仓，M 只重复跳过，X 只未查到净值」

**反推公式**：
```
成本 = 持仓金额 / (1 + 收益率% / 100)
份额 = 持仓金额 / 基金当前净值
```

---

## 三、数据模型

### 3.1 State（唯一权威：`store.js::defaultState()`）

```javascript
{
  version: 3,
  settings: {
    defaultStrategy: 'NORMAL',  // 'NORMAL' | 'AGGRESSIVE'，全局默认策略预置 key
    assetTargets: { equity: 60, bond: 30, gold: 10 }  // 三资产大类目标比例（%，0-100）
  },
  categories: [{ name: String, targetPct: Number }],
  funds: [Fund]
}
```

### 3.2 Fund

```javascript
{
  id: String,              // crypto.randomUUID()
  code: String,            // 6 位数字
  name: String,
  category: String,        // 对应 categories[].name，空=未分类
  assetClass: String,      // 'EQUITY' | 'BOND' | 'GOLD'，缺省 'EQUITY'
  ftype: String,           // 东财 F10 FTYPE 原值（如'指数型-股票'），持仓卡片展示
  assetClassAuto: Boolean, // true=大类跟随 FTYPE 自动归类；false=用户手动指定
  nav: Number,             // 当前净值
  navDate: String,         // YYYY-MM-DD
  navUpdatedAt: Number,   // ms timestamp
  navHistory: [{ date: String, nav: Number }], // 历史净值快照（已排序）
  trades: [Trade],
  strategyOverride: 'NORMAL' | 'AGGRESSIVE' | 'NONE' | null,  // 单基金策略覆盖，null=跟随全局
  tierState: Boolean[],           // 补仓档位执行状态，与生效预置方案 addTiers 对齐
  logicIntact: Boolean,           // true
}
```

### 3.3 Trade

```javascript
{
  id: String,
  type: 'BUY' | 'SELL',
  date: String,         // YYYY-MM-DD
  nav: Number,          // 成交净值
  amount: Number,        // 买入总金额 / 卖出总金额
  shares: Number,        // 成交份额（可省略，省略时按 amount/nav 反推）
  fee: Number,           // 手续费
  source: 'BASE' | 'ADD', // BASE = 底仓/手动，ADD = 补仓档位触发
  tierIndex: Number | null, // 补仓来源档位索引（ADD 交易专属）
  note: String,          // 备注
  closed: Boolean,       // 是否已独立了结
  createdAt: Number,     // ms timestamp
}
```

### 3.4 Category

```javascript
{
  name: String,       // 类别名，唯一
  targetPct: Number,  // 目标占比（%，0-100）
}
```

### 3.5 版本迁移规则

- `store.js::VERSION` 与 localStorage 中的 `state.version` 必须一致
- `normalizeState()` 负责旧数据补齐，**禁止假设旧数据一定有新字段**
- 迁移必须幂等（同一版本重复跑不报错）
- 字段清洗规则：
  - `settings.defaultStrategy`：旧对象型策略 → 数值映射（stopLossPct ≤ 10 → `'AGGRESSIVE'`，否则 `'NORMAL'`；字段缺失/非法 → `'NORMAL'`）；新版字符串 ∈ NORMAL/AGGRESSIVE 保留，其余 → `'NORMAL'`
  - `strategyOverride`：旧对象型（非空）→ 同上映射为预置 key；空对象/null → null（跟随全局）；字符串 ∈ NORMAL/AGGRESSIVE/NONE 保留，其余 → null
  - `tierState`：从 Boolean 数组清洗
  - `navHistory`：按 date 升序排序，过滤 nav ≤ 0 的记录
  - `trades`：shares/fee 从原始数据读取，不存在时 num() 返回 0
  - `source`：原始数据中的 source === 'MANUAL' 视为 'BASE'
  - `assetClass`：非法值一律归为 'EQUITY'；`ftype` 缺省补 ''；`assetClassAuto` 缺省补 true
  - `settings.assetTargets`：非法/缺失时回退默认值 { equity:60, bond:30, gold:10 }，数值钳制 0–100

---

## 四、计算口径（唯一权威：`strategy.js`）

### 4.1 持仓计算

| 指标 | 公式 | 函数 |
|------|------|------|
| 持仓份额 | `Σ 买入份额 − Σ 卖出份额`（SELL 按均价扣减 cost） | `computePosition()` |
| 摊薄成本 | `(Σ 买入金额 + 买入手续费 − 卖出对应成本) / 剩余份额` | `computePosition()` |
| 底仓成本 | `底仓交易合计金额 / 底仓交易合计份额`（排除 source='ADD' 的补仓） | `computePosition()` |
| 已实现收益 | `Σ (卖出金额 − 卖出手续费 − 卖出成本)` | `computePosition()` |
| 市值 | `份额 × 当前净值` | `computeFundMetrics()` |
| 持仓盈亏 | `市值 − 成本` | `computeFundMetrics()` |
| 持仓盈亏率 | `盈亏 / 成本 × 100%` | `computeFundMetrics()` |
| 回撤% | `(avgCost − nav) / avgCost × 100%` | `computeFundMetrics()` |

**所有计算必须是纯函数**：无副作用、输入相同则输出相同、可单测。

### 4.2 策略规则线

| 指标 | 公式 | 锚点 |
|------|------|------|
| 止损线 | `平均成本 × (1 − 止损比例%)` | avgCost |
| 止盈线 | `平均成本 × (1 + 止盈比例%)` | avgCost |
| 分档触发价 | `底仓成本 × (1 − 档位跌幅%)` | baseCost（补仓后不变） |

**补仓后换锚**：止损线和止盈线随新 avgCost 重算，但分档触发价锚定 baseCost 不变。

**未启用策略（NONE）**：止损线、止盈线、分档触发价均不计算（返回 0 / 空数组），状态为 `none`。

### 4.3 状态判断优先级

```
0. 无策略     fund.strategyOverride === 'NONE' → status = 'none'，跳过以下判断
1. 止损触发   nav ≤ stopLossNav
2. 移动止盈   已达止盈线 + 峰值回撤 ≤ trailingStopNav
3. 止盈触发   nav ≥ takeProfitNav
4. 补仓可执行 存在 nav ≤ tier.triggerNav 的未执行档位
5. 接近止损   nav ≤ stopLossNav × 1.02
6. 正常       以上都不满足
```

### 4.4 移动止盈逻辑

```
峰值 peakNav = max(当前净值, 历史快照, 所有买入成交净值)
触发起盈峰值 peakNav ≥ takeProfitNav
触发止盈信号 nav ≤ peakNav × (1 − trailingStopPct%)
```

### 4.5 独立了结（补仓批次收益）

每笔 source='ADD' 且未 closed 的 BUY 交易独立跟踪收益率：

```
批次收益率 = 当前净值 / 补仓成交净值 − 1
建议了结 = 批次收益率 ≥ addPositionSellPct%
```

### 4.6 资产配置计算

```
实际占比 = 类别市值 / 总资产市值 × 100
偏差 = 实际占比 − 目标占比（正=超配红，负=低配绿）
目标市值 = 目标占比% × 总资产市值
再平衡金额 = 目标市值 − 实际市值（正=需买入，负=需卖出）
```

**口径**：统一用 `marketValue = shares × currentNav` 做占比分母，无持仓（shares=0）的基金不计入。

### 4.7 三资产再平衡计算（权益/债券/黄金）

```
大类实际市值 = Σ 该大类下有持仓基金的 marketValue
大类实际占比 = 大类实际市值 / 总资产市值 × 100
大类偏差 = 实际占比 − settings.assetTargets 中对应目标%（正=超配，负=低配）
大类调仓金额 = 目标市值 − 实际市值（正=需买入，负=需卖出）
```

- 函数：`strategy.js::computeThreeAssetAllocation(state, metricsMap)`，纯函数
- 基金大类取 `fund.assetClass`（store 层保证非空且合法）
- `assetTargets` 为空/非法时回退 { equity:60, bond:30, gold:10 }

### 4.8 宏观指标计算（`macro.js`）

| 指标 | 公式 |
|------|------|
| 股债收益比 | 盈利收益率 / (中国10Y% / 100)，见 2.2.4 |
| 期限利差(bp) | (长端收益率% − 短端收益率%) × 100（美国与中国的 10Y−2Y） |
| WTI 同比% | (WTI现价 / 365天前收盘 − 1) × 100 |
| 美国实际利率%（近似） | 美国10Y% − WTI同比% |

### 4.9 估值水平与当日买入（`strategy.js`）

```
估值分位 percentile = 序列中 ≤ 当前值（最新收盘）的样本数 / 样本总数 × 100
label/tone：percentile ≤ 30 → 低估（down）；30–70 → 正常（flat）；≥ 70 → 高估（warn）
样本 < 20 条或当前值非法 → null（界面不显示标签）
```

- 函数：`strategy.js::computeValuationLevel(values, current, { invert })`，纯函数；values 为收盘/收益率数组，`invert: true` 时分位取反（债券口径：收益率低=债贵）
- 分级辅助：`strategy.js::gradeValuationPercentile(percentile)`
- 接口封装：`quote.js::fetchFundBasicInfo(code)`（F10 基本信息分流）+ `macro.js::fetchKlineClose(secid, beg)`（估值序列），失败返回 null，历史禁止写入 localStorage
- 指数股票基金用跟踪指数价格分位（数学上等价于常数盈利下的 PE 分位，界面标注近似）
- **当日买入口径**：`trade.date === 今天` 的买入份额，市值按成交净值（trade.nav，即当日收盘净值）计算，不参与当日涨跌（今日买入份额无昨日基准）；摊薄成本口径不变

---

## 五、代码架构

### 5.1 模块职责（严格分层）

```
js/
├── store.js     → 数据持久化（localStorage 读写、版本迁移、导入导出、CSV 解析）
├── strategy.js  → 纯计算（成本/仓位/补仓/配置分析/策略校验）
├── quote.js     → 东方财富净值接口封装（批量拉取 + 单只查询）
├── macro.js     → 宏观数据（行情批量 + 历史K线 + 股债性价比分位，5分钟内存缓存）
├── ui.js        → UI 原子能力（格式化、Toast、Sheet、颜色工具）
├── views.js     → 页面模板（纯字符串拼接，不含业务逻辑）
└── app.js       → 应用壳（路由、状态、事件委托、刷新调度）
```

**依赖方向**：`store` ← `strategy` ← `views` ← `app`，`quote/macro/ui` 可被任意层引用。**禁止反向依赖**。

### 5.2 事件约定（委托模式）

所有交互通过 `data-action` 属性 + `document.addEventListener('click')` 统一处理。**禁止在 HTML 模板中写内联 onclick**。

已注册的 action：

| action | 触发位置 | 行为 |
|--------|---------|------|
| refresh-all | 持仓页顶部 | 批量刷新全部基金净值 |
| macro-refresh | 宏观页顶部 | 强制刷新宏观数据（跳过缓存） |
| filter-holdings | 持仓页筛选 tab | 切换筛选状态 |
| toggle-alloc | 配置页类别头部 | 展开/收起基金明细 |
| unassign-category | 配置页基金行 | 从类别中移除 |
| lookup-fund | 添加基金弹层 | 查询名称与净值 |
| add-fund | FAB / 空状态按钮 | 打开添加基金弹层 |
| save-strategy | 策略页表单提交 | 保存全局默认策略（普通 / 激进单选） |
| batch-parse | 数据页批量导入 | 解析文本预览 |
| batch-import-file | 数据页批量导入 | 触发本地文件选择框（.csv/.txt），加载后自动解析 |
| batch-import-confirm | 数据页批量导入 | 确认导入 |

### 5.3 状态管理

- **全局状态**：`app.js::state`（来自 `store.load()`），单一数据源
- **UI 临时状态**：模块级变量（不持久化）
  - `holdingsFilter`：持仓页筛选状态（'all' / 'add' / 'take' / 'stop' / 'normal'）
  - `expandedAllocCats`：配置页展开的类别名 Set
  - `macroLoading`：宏观数据加载中
  - `macroData`：宏观数据缓存
  - `refreshing`：净值刷新中
- **渲染触发**：状态变更后调用 `render()`，**禁止手动操作 DOM**

### 5.4 模板参数

各页面渲染函数签名：

| 函数 | 参数 |
|------|------|
| `holdingsPage(state, metricsMap, { refreshing, filter, valuations })` | 状态 + 指标映射 + 选项（valuations=基金代码→估值水平 Map） |
| `macroPage(data, { refreshing })` | 宏观数据 + 选项 |
| `allocationPage(state, metricsMap, expandedCats)` | 状态 + 指标 + 已展开类别 |
| `strategyPage(state)` | 状态（双预置卡 + 全局默认单选） |
| `dataPage(state)` | 状态 |
| `fundDetailPage(state, fund, metrics)` | 状态 + 基金 + 指标 |
| `overrideSheetBody(fund, defaultKey)` | 基金 + 全局默认 key（策略覆盖下拉） |

---

## 六、数据源

### 6.1 净值（quote.js）

| 接口 | 用途 | CORS | 降级 |
|------|------|------|------|
| `fundmobapi.eastmoney.com/fundguzhi` | 批量净值（主） | ✅ | 手动录入 |
| `fundgz.1234567.com.cn/js/{code}.js` | 单只估值（JSONP） | ✅ | 手动录入 |
| `fundmobapi.eastmoney.com/FundMNewApi/FundMNBasicInformation` | F10 基金基本信息（估值标签分流：FTYPE / INDEXCODE / INDEXTEXCH） | ✅ | 不显示标签 |

### 6.2 宏观（macro.js）

| 接口 | 用途 |
|------|------|
| `push2.eastmoney.com/api/qt/ulist.np/get` | 美债/美元/中债/商品/沪深300（一次请求） |
| `push2.eastmoney.com/api/qt/stock/get` | 沪深300 PE-TTM（近似口径：f114 ÷ 10，guard 5–200） |
| `push2his.eastmoney.com/api/qt/stock/kline/get` | 沪深300 + 中债 5年日K + WTI 1年日K + 估值序列（跟踪指数/COMEX黄金/中债10Y 约 2 年日K） |

**兜底链路**（任一层失败自动降级到下一层，界面显示降级提示）：

| 层级 | 数据源 | 说明 |
|------|--------|------|
| 1 | push2 主域 → 镜像域名（push2delay / 90.push2 等） | 同一接口换域名轮询 |
| 2 | 同接口 JSONP 桥接（`cb=` 参数 + `<script>` 注入） | 绕过 fetch/CORS 拦截 |
| 3 | 天天基金代理：`fundmobapi.eastmoney.com` 批量净值（CORS，一次请求）→ `fundgz.1234567.com.cn/js/{code}.js` JSONP 补漏 | 黄金←000217、原油←501018、沪深300←000961，仅补日涨跌 |

- 收益率类指标（美/中 10Y/5Y）与 PE 无代理数据源，降级时显示「—」
- 降级标志随缓存写入 data：`quotesFailed / proxyUsed / peMissing / historyMissing`

### 6.3 缓存策略

- 宏观数据：内存 5 分钟缓存，`macro.js::cache` 对象
- 净值：每次刷新直接覆盖 `fund.nav` + `fund.navDate` + `fund.navUpdatedAt`
- 历史净值快照：每次刷新时追加到 `fund.navHistory`，按日期排序去重
- 估值分位：内存 30 分钟缓存（`app.js::valuationCache` 按基金代码 + 同类型序列按 key 去重），失败在缓存期内不重试、不阻塞页面，**禁止写入 localStorage**

---

## 七、测试规范

### 7.1 框架

Node 原生 ESM（`node tests/*.test.mjs`），**零测试框架依赖**。

### 7.2 测试范围

| 文件 | 覆盖模块 |
|------|---------|
| `tests/strategy.test.mjs` | 持仓成本、补仓模拟、资产配置分析、三资产再平衡、策略校验、双预置解析（resolveStrategyByKey）、估值水平（computeValuationLevel 分级/债券取反/指数价格分位等价）、当日买入口径、策略数据迁移 |
| `tests/batch-import.test.mjs` | CSV 解析器 parseBatchText |
| `tests/macro.test.mjs` | computePercentile、computeEquityBond 分位、期限利差、WTI 同比、实际利率 |

### 7.3 编写规则

- 给定输入 → 断言输出，可读可追溯
- 覆盖边界值：空数组 / 负数 / 零值 / NaN / 超大数
- 注释说明测试意图
- **禁止 mock 网络请求**：测试只覆盖纯函数

---

## 八、设计风格

### 8.1 色彩变量（唯一权威：`css/styles.css` 顶部）

| 变量 | 亮色 | 深色 | 用途 |
|------|------|------|------|
| `--accent` | `#2456d8` | `#5b8cff` | 主色 |
| `--up` | `#e63b32` | `#ff5d55` | 上涨/超配/止损 |
| `--down` | `#16a34a` | `#3ddc84` | 下跌/低配/补仓 |
| `--danger` | `#e0322a` | `#ff5d55` | 危险 |
| `--ok` | `#1a9950` | `#4ade80` | 成功 |
| `--warn` | `#ff9f0a` | `#ffd60a` | 警告 |

**禁止在组件内硬编码颜色**。深色模式通过 `@media (prefers-color-scheme: dark)` 统一覆盖，禁止组件内单独写深色变体。

### 8.2 组件规范

| 组件 | 实现位置 | 约束 |
|------|---------|------|
| 顶部栏 | `views.js` → `topbar` + `topbar-row` | 固定 64px，eyebrow + 大标题 + 操作按钮 |
| Hero 卡 | `views.js` → `hero-card` | 左对齐三行 |
| 底部导航 | `index.html` → `tabbar` | 5 固定 tab |
| 基金卡片 | `views.js` → `fundCard` | 标题+净值+三指标+rule-track+hint |
| 状态胶囊 | `views.js` → `badge` | tone: ok/warn/accent/danger |
| 进度条 | `rule-track` + `alloc-bar-track` + `pie-dev-track` | 统一 6px，绿→橙→红渐变轨道 |
| 底部弹层 | `ui.js` → `sheet` | iOS 安全区适配 |
| Toast | `ui.js` → `toast` | 顶部居中 2.5s |
| FAB | `index.html` → `.fab` | 仅持仓页 |
| Tab 筛选 | `views.js` → `filter-tabs` | 胶囊，带数量角标 |
| 宏观卡片 | `views.js` → `macro-card grad-*` | 四色渐变背景 |

### 8.3 布局与间距

- 页面容器：`.page`，`max-width: 480px` 居中
- 卡片间距：`gap: 12px`（基金列表）/ `gap: 14px`（宏观卡）
- 圆角：卡片 `16px`，按钮 `10px`，tab `999px`
- iOS 安全区：底部 `env(safe-area-inset-bottom)`，顶部 `env(safe-area-inset-top)`
- 16px 输入防缩放

### 8.4 术语对照

| 场景 | 统一用词 | 禁止用词 |
|------|---------|---------|
| 基金 | 代码 / 名称 / 净值 | 股票 / 代码号 / 净值日期 |
| 盈亏 | 持仓收益 / 已实现收益 | 浮动盈亏 / 已清仓收益 |
| 补仓 | 第 N 档 / 档位触发价 | 第 N 层 / 补仓点 |
| 止盈 | 触发止盈 / 移动止盈 | 获利了结 / 阶梯止盈 |
| 配置页 | 类别 / 目标比例 / 偏差 | 资产类 / 目标权重 / 偏离度 |

---

## 九、已知边界

| # | 限制 | 影响 | 可能的改进方向 |
|---|------|------|---------------|
| 1 | 无账号与云同步 | 换设备/浏览器需手动导入导出 | Cloudflare KV + Worker |
| 2 | 净值仅日终数据 | 盘中无法看到实时盈亏 | 接入天天基金估值接口 |
| 3 | 宏观数据缓存 5 分钟 | 高频刷新时可能看到重复值 | 加强制刷新按钮 |
| 4 | 策略回测缺失 | 用户无法知道档位是否合理 | 用东财 K 线接口模拟 |
| 5 | 无自动定时刷新 | 需手动点刷新 | 交易时段自动轮询 |
| 6 | 接口单点依赖东财 | CORS 变更或接口下线即失效 | 加天天基金 fallback |
| 7 | 分红按红利再投资理解 | 现金分红需手动记账 | 后续考虑 |
| 8 | 美国通胀预期无 CORS 接口 | 实际利率用 US10Y − WTI同比 近似 | 接入美债 TIPS 盈亏平衡通胀数据 |
| 9 | 宏观 verdict 为规则映射 | 极端行情下阈值判断可能与直觉不符 | 引入滚动窗口动量辅助 |
| 10 | 估值水平标签按基金类型分流：债券（中债10Y收益率分位取反）、黄金（金价分位）、指数股票（跟踪指数价格分位）；主动/行业/QDII 基金不显示 | 接口失败或样本不足（< 20 条）时不显示标签；指数 PE 为价格分位近似 | 行业基金接入 PB 分位；接入真实指数 PE 数据源 |

---

## 十、变更记录

| 版本 | 日期 | 变更内容 |
|------|------|---------|
| v1.0 | 2026-11-19 | 基于当前代码现状首次生成完整需求文档 |
| v1.1 | 2026-11-19 | 宏观页改为「每指标一卡 + 一句话平衡方向」；新增美国实际利率（近似）、美/中期限利差、美元、中美利差卡片；新增三资产（权益/债券/黄金）目标比例与再平衡计算；数据模型新增 fund.assetClass 与 settings.assetTargets |
| v1.2 | 2026-11-19 | 宏观数据源新增三级兜底：push2 镜像域名轮询 → 同接口 JSONP 桥接 → 天天基金估值代理基金（黄金/原油/沪深300 日涨跌），页面底部显示降级提示 |
| v1.3 | 2026-11-19 | 宏观页顶部新增「资产方向速览」：权益/债券/黄金/石油四行一句话方向建议，基于既有宏观指标自动推导 |
| v1.4 | 2026-11-19 | viewport 禁用手势缩放（maximum-scale=1, user-scalable=no）；批量导入底仓新增「加载本地文件」方式（.csv/.txt ≤1MB，自动去 BOM 并解析预览） |
| v1.5 | 2026-11-19 | 宏观页新增 COMEX 黄金、NYMEX 原油两张指标卡（含方向话术）；股债性价比卡明确展示「盈利收益率 = 1 ÷ PE-TTM」计算因子 |
| v1.6 | 2026-11-19 | 配置页拆分为两个标签：「三资产」（默认，权益/债券/黄金再平衡 + 宏观方向建议）与「自定义分类」（自定义标签与权重的类别占比/偏差/管理） |
| v1.7 | 2026-11-19 | 三资产行样式与自定义分类统一（alloc-row 体系：折叠明细 + 平衡进度条）；新增宏观推荐方案自动切换：进攻 70/20/10、平衡 60/30/10、偏金 55/25/20、防守 40/40/20，规则与宏观页方向速览一致 |
| v1.8 | 2026-11-19 | 三资产目标比例改为完全由预置推荐方案决定（宏观数据缺失按「平衡」兜底），移除手动目标输入与「保存目标比例」按钮，用户只维护基金的大类归属 |
| v1.9 | 2026-11-19 | 持仓页改为进入时按需拉取净值（≥5 分钟间隔，无轮询定时器）；当日买入份额按成交净值计市值（不参与当日涨跌）；新增基金估值水平标签（近一年净值分位：低估/正常/高估，30 分钟内存缓存）；策略改为双预置方案（普通/激进）+ 全局默认单选 + 单基金覆盖下拉（跟随全局/普通/激进/不启用），数据模型 version 2→3（旧对象型策略按 stopLossPct≤10 映射为预置 key） |
| v1.10 | 2026-11-20 | 修复 WTI 同比始终为空（400 自然日窗口仅约 284 条交易日样本，低于 300 条阈值）：窗口扩至 450 自然日、阈值降至 250 条；中/美期限利差改用 10Y−2Y 口径（实测东财存在 171.CN2Y / 171.US2Y 品种）；移除美元指数卡（并入 COMEX 黄金卡展示）与中美利差卡 |
| v1.11 | 2026-11-20 | 宏观页新增「通胀与景气 · 经济周期锚」卡：CPI 同比 / PPI 同比 / PPI−CPI 剪刀差 / 制造业与非制造业 PMI，PMI 四档荣枯线方向话术；数据源为东财数据中心 datacenter 接口（CORS 开放），经济数据单独当日有效缓存 |
| v1.12 | 2026-11-20 | 估值水平标签改造：按基金类型分流——债券基金用中债10Y收益率分位取反（收益率低=债贵）、黄金基金用 COMEX 金价分位、指数股票基金用跟踪指数价格分位（常数盈利 PE 分位的等价近似）、主动/行业/QDII 基金不显示标签；数据源改用东财 F10 `FundMNBasicInformation`（FTYPE/INDEXCODE/INDEXTEXCH）+ push2his K 线（约 2 年窗口）；修复沪深300 PE 取值（f115 不可靠，改 f114÷10 + 5–200 合理性 guard，界面标注近似口径） |
| v1.13 | 2026-11-20 | 基金自动归类三资产：数据模型新增 fund.ftype（F10 FTYPE 原值，持仓卡片展示）与 fund.assetClassAuto（手动指定标记）；添加/批量导入/持仓页估值加载时按 classifyAssetClass 自动归入 EQUITY/BOND/GOLD，配置页手动改大类或添加时显式选债券/黄金后不再覆盖 |

---

## 十一、禁止事项（红线）

1. **禁止引入任何 npm 依赖**（构建工具、UI 库、测试框架都不行）
2. **禁止引入任何后端服务**（云数据库、API 网关、Serverless 都不行）
3. **禁止在组件内硬编码颜色**（必须走 CSS 变量）
4. **禁止在 HTML 模板中写内联事件处理**（必须走 `data-action` 委托）
5. **禁止在纯函数模块（strategy.js）中写 DOM 操作**
6. **禁止把网络响应直接存入 localStorage**
7. **禁止假设 localStorage 中的数据一定是最新 schema**（必须 normalize）
8. **禁止删除 store.js::VERSION 字段**（版本迁移的基石）
